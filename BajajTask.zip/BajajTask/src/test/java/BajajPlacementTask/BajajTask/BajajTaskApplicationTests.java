package BajajPlacementTask.BajajTask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BajajTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
